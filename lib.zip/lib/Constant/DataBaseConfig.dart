class DataBaseConfig
{
 static String ip='';/// localhost 216.48.186.108
 static String database=''; // SK
 static String userId=''; //Sa
 static String password='';//BusOn@123
}