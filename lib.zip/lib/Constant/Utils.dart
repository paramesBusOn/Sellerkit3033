class Utils {
  static String? token = '';
  static String appversion = '';
  static String apIversion = '';
  static String? tenetID = '';
  static String sapUserType = '';
  static String slpcode = '';
  static String? firstName = '';
  static String? lastName = '';
  static String? profilepic = '';
  static String? mailId = '';
  static String? phoneNum = '';
  static String? branch = '';
  static String? deviceId = '';
  static String? managerPhonenum = '';
  static String? userNamePM = '';
  static String userId = '';
  static int? storeid;
  static String ipaddress = '';
  static String ipname = '';
  static String? latitude = '';
  static String? langtitude = '';
  static String? headerSetup = '';
  static String? encryptedSetup = '';
  static String? storecode = '';
  static String? usercode = '';
  static String? password = '';
  //For Using URL or API
  static String sLUrl = '';
  static String queryApi = '';
  static String defaultversion= '1.0.1';
  static String network= '';
static int? slidevalue=10;
}
