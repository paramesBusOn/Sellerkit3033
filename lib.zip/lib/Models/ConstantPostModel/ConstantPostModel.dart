class Constant{
  String? ip;
  String? dbname;
  String? username;
  String? pass;
  String? query;
  
  // Server=164.52.214.147;Database=JRF1;User Id=Sa; Password=BusOn@123;
}