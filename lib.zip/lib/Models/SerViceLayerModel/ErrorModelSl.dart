class ErrorModel{
  int? code;
  Message?message;
 ErrorModel({
   this.code,
  this.message
 });

  factory ErrorModel.fromJson(dynamic jsons) {
    return ErrorModel(
      code: jsons['code']as int,
     message: Message.fromJson(jsons['message']),
       );
 }
}

 class Message{
  String ?lang;
  String ? value; 
 Message({
   this.lang,
   this.value,
 });

  factory Message.fromJson(dynamic jsons) {
    return Message(
    //  groupCode: jsons['GroupCode'] as int, 
      lang: jsons['lang']as String,
      value: jsons['value'] as String,
   
       );
 }
 }