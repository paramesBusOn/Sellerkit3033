class Url{
//  static String url2 = 'http://216.48.186.108:19979/api/';
 static String SLUrl = '';
 static String queryApi = '';//'http://216.48.186.108:19979/api/';//SellerKit//using this //http://216.48.186.108:19979/api/
}