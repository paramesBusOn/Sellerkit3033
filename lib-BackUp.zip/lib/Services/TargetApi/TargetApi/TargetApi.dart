import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:sellerkit/Constant/Configuration.dart';
import 'package:sellerkit/Constant/DataBaseConfig.dart';
import 'package:sellerkit/Models/TargetModel/TargetModel.dart';
import 'package:sellerkit/Services/URL/LocalUrl.dart';
// import 'package:sellerkit/main.dart';
import '../../../Constant/ConstantSapValues.dart';

class GetTargetApi {
  static Future<TargetModal> getData(
      // sapUserId,
      ) async {
    int resCode = 500;
    try {
      log("URRRRRL"+Url.queryApi + 'SkClientPortal/GetTargetTab2?SlpCode=${ConstantValues.slpcode}&');
            Config config = Config();

      await config.getSetup();
       final response = await http.get(Uri.parse(Url.queryApi + 'SkClientPortal/GetTargetTab2?SlpCode=${ConstantValues.slpcode}&'),
          // ('http://164.52.214.147:47182/api/SellerKit'),

          headers: {
            "content-type": "application/json",
            "Authorization": 'bearer ' + ConstantValues.token,"Location":'${ConstantValues.EncryptedSetup}'
          },
          // body: jsonEncode({
          //   "constr":
          //       "Server=${DataBaseConfig.ip};Database=${DataBaseConfig.database};User Id=${DataBaseConfig.userId}; Password=${DataBaseConfig.password};",
          //   "query":
          //       "Exec SK_GET_SALES_TARGET_KPI '${ConstantValues.slpcode}'",
          // })
          );

      resCode = response.statusCode;
      print(response.statusCode.toString());
      log("GETTargetRes"+json.decode(response.body).toString());
      if (response.statusCode == 200) {
        return TargetModal.fromJson(json.decode(response.body), resCode);
      } else {
        print("Error: ${json.decode(response.body)}");
        return TargetModal.error('Error', resCode);
      }
    } catch (e) {
      print("Exception: " + e.toString());
      return TargetModal.error(e.toString(), resCode);
    }
  }
}
