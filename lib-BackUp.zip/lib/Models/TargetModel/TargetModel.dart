import 'dart:convert';

class TargetModal {
  List<TargetData>? targetdata;
  String? message;
  bool? status;
  String? exception;
  int? stcode;
  TargetModal(
      {required this.targetdata,
      required this.message,
      required this.status,
      this.exception,
      required this.stcode});
  factory TargetModal.fromJson(List<dynamic> jsons, int stcode) {
    if (jsons != null && jsons.isNotEmpty ) {
      var list = jsons as List;
      List<TargetData> dataList =
          list.map((data) => TargetData.fromJson(data)).toList();
      return TargetModal(
          targetdata: dataList,
          message: "Success",
          status: true,
          stcode: stcode,
          exception: null);
    } else {
      return TargetModal(
          targetdata: null,
          message: "Failure",
          status: false,
          stcode: stcode,
          exception: null);
    }
  }

  factory TargetModal.error(String jsons, int stcode) {
    return TargetModal(
        targetdata: null,
        message: null,
        status: null,
        stcode: stcode,
        exception: jsons);
  }
}

class TargetData {
  String? tPeriod;
  String? kPI1Title;
  String? kPI1MainValue;
  String? kPI1SubValue;
  String? kPI2Title;
  String? kPI2MainValue;
  String? kPI2SubValue;
  String? kPI3Title;
  String? kPI3MainValue;
  String? kPI3SubValue;
  String? kPI4Title;
  String? kPI4MainValue;
  String? kPI4SubValue;
  TargetData({
    required this.tPeriod,
    required this.kPI1MainValue,
    required this.kPI1SubValue,
    required this.kPI1Title,
    required this.kPI2MainValue,
    required this.kPI2SubValue,
    required this.kPI2Title,
    required this.kPI3MainValue,
    required this.kPI3SubValue,
    required this.kPI3Title,
    required this.kPI4MainValue,
    required this.kPI4SubValue,
    required this.kPI4Title,
  });

  factory TargetData.fromJson(Map<String, dynamic> json) => TargetData(
        tPeriod: json['tPeriod'] ?? "",
        kPI1MainValue: json['kpI_1_MainValue'] ?? "",
        kPI1SubValue: json['kpI_1_SubValue'] ?? "",
        kPI1Title: json['kpI_1_Title'] ?? "",
        kPI2MainValue: json['kpI_2_MainValue'] ?? "",
        kPI2SubValue: json['kpI_2_SubValue'] ?? "",
        kPI2Title: json['kpI_2_Title'] ?? "",
        kPI3MainValue: json['kpI_3_MainValue'] ?? "",
        kPI3SubValue: json['kpI_3_SubValue'] ?? "",
        kPI3Title: json['kpI_3_Title'] ?? "",
        kPI4MainValue: json['kpI_4_MainValue'] ?? "",
        kPI4SubValue: json['kpI_4_SubValue'] ?? "",
        kPI4Title: json['kpI_4_Title'] ?? "",
      );
}
