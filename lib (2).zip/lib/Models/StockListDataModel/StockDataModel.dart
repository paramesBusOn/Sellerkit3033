class StockListDataModel{
 String? brand;
 String? segment; 
 String ?division;
 String ?cateogory; 
 String ?slpcode; 
 String ?companyid;
 String ?items;

 StockListDataModel({ this.brand, this.cateogory,  this.companyid,
  this.division, this.items,  this.segment, this.slpcode
 });
}